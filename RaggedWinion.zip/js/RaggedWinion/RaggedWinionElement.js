/**
 * 
 */
function RaggedWinionElement(
	resistencia
	, imagenSRC
	, fotogramaAparicion
	, altura
	, alto
	, ancho
	, solido
	, mortal
	, movil
	, velocidadAscenso
	, ascendiendo
){
	/******* CONSTRUCTOR *******/	
	
	/**Atributos - Atributes**/
	var recorrido = 0;
	var destruido = false;
	var fotogramaDestruccion = null;
	var fotogramaSalto = null;
	var fotogramaDisparo = null;
	
	/**Funciones de Inicio - Onload functions**/
	
	/**Asignacion de Eventos - Events' Asignations**/
	
	/**Registro - Logs**/
	
	
	/******* FIN DEL CONSTRUCTOR *******/
	
	
	
	
	/**
	 * Método que dibuja el elemento.
	 * Method which draws the element.
	 * 
	 * @param contexto Canvas Context
	 * @param anchoPantalla integer
	 * @param zoom integer
	 * @param fotogramaActual integer
	 */
	this.dibujar = function(contexto, anchoPantalla, zoom, fps, fotogramaActual){
		var img = null;
		
		if(!destruido){
			img = new Image();
			switch(parseInt(fotogramaActual/2/fps)%4){
				case 0:
					img.src = "src/" + imagenSRC +"A.png";
					break;
				case 1:
					img.src = "src/" + imagenSRC +"B.png";
					break;
				case 2:
					img.src = "src/" + imagenSRC +"C.png";
					break;
				case 3:
					img.src = "src/" + imagenSRC +"B.png";
					break;
			}
		}
		
		if(img != null){
			contexto.drawImage(img, parseInt((anchoPantalla - recorrido)*zoom), parseInt((altura-20)*zoom), ancho*zoom, alto*zoom);
		}
	};
	
	
	/**
	 * Método que mueve el elemento.
	 */
	this.avanzar = function(avanzado){
		recorrido += avanzado;
	};
	
	
	/**
	 * Función que retorna la altura maxima y minima del elemento.
	 */
	this.getPosicion = function(anchoPantalla){
		return {superior: altura, inferior: altura+alto, derecha: anchoPantalla-recorrido+ancho, izquierda: anchoPantalla-recorrido};
	};

	
	/**
	 * Función que devuelve true si el elemento es solido.
	 */
	this.getSolido = function(){
		return solido;
	};

	
	/**
	 * Función que devuelve true si el elemento es mortal.
	 */
	this.getMortal = function(){
		return mortal;
	};
	
	
	/**
	 * Método que mueve el elemento.
	 */
	this.estaFuera = function(anchoPantalla){
		if(destruido){
			return true;
		}
		
		else if(anchoPantalla + 5 * ancho - recorrido <= 0){
			return true;
		}
		
		else{
			return false;
		}
	};
};