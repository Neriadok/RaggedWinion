/**
 * 
 * @param animaciones
 * @param jugador
 * @param capaElementos
 * @param fondo
 */
function RaggedWinionGame(
	pantalla
	,animaciones
	,capaPersonaje
	,capaElementos
	,fondo
){
	/******* CONSTRUCTOR *******/	
	
	/**Atributos - Atributes**/
	var relacionDimensiones = 75/100;
	var zoom = 1;
	var ancho = 1000;
	var alto = ancho * relacionDimensiones;
	
	var fps = 40;
	var fpsRealesAnimaciones = fps;
	var fpsRealesElementos = fps;
	var fpsRealesPersonaje = fps;
	var fpsRealesElementos = fps;
	var fpsRealesFondo = fps;
	
	var velocidadMax = 20;
	var velocidadMin = 10;
	var velocidad = velocidadMin;
	var aceleracion = 2;
	var inicio = false;
	var pausa = true;
	var fotogramas = 0;
	var fechaUltimoFotograma = new Date().getTime();
	var fechaInicio = fechaUltimoFotograma;

	var red = 100;
	var blue = 255;
	var green = 100;
	var bgColor = "rgb("+ red +","+ green +","+ blue +")";
	var velocidadCambioColor = 1.69014;

	var personaje = new RaggedWinionCharacter("personaje", ancho);
	var elementos = [];

	pantalla.style.zIndex = "1";
	fondo.style.zIndex = "2";
	capaElementos.style.zIndex = "3";
	capaPersonaje.style.zIndex = "4";
	animaciones.style.zIndex = "5";
	
	var contextoAnimaciones = animaciones.getContext("2d");
	var contextoPersonaje = capaPersonaje.getContext("2d");
	var contextoElementos = capaElementos.getContext("2d");
	var contextoFondo = fondo.getContext("2d");

	var contadorFpsAnimaciones = new ContadorFPS(animaciones, fps);
	var contadorFpsPersonaje = new ContadorFPS(capaPersonaje, fps);
	var contadorFpsElementos = new ContadorFPS(capaElementos, fps);
	var contadorFpsFondo = new ContadorFPS(fondo, fps);
	
	
	/**Funciones de Inicio - Onload functions**/
	redimensionar();
	
	/**Asignacion de Eventos - Events' Asignations**/
	document.onkeydown = verificarTecla;
	
	/**Registro - Logs**/
	console.log("fps: "+fps);
	console.log("ancho: "+ancho);
	console.log("zoom: "+zoom);
	console.log("bgColor: "+bgColor);
	
	/**Ciclo de Juego - Game interval*/
	var cicloComprobar = setInterval(
		function (){
			redimensionar();
			if(personaje.getEliminado()){
				texto("GAME OVER (esc)");
				animaciones.style.backgroundColor = "rgb(90,20,20)";
			}
			
			else if(!pausa){
				animaciones.style.backgroundColor = "transparent";
				nuevoFotograma();
			}
			
			else{
				texto("Pulsa 'Enter' para continuar");
				animaciones.style.backgroundColor = "rgb(10,20,20)";
			}
		}
		,1 / fps * 1000
	);
	
	/******* FIN DEL CONSTRUCTOR *******/
	
	
	
	/**
	 * Función que evalua que tecla se ha pulsado y en algunos casos llama a otras funciones.
	 * Function that verifies which key was pressed and, in some cases, call other functions.
	 */
	function verificarTecla(e){
		switch(e.keyCode){
			case 37: 
				cambiarVelocidad(-aceleracion);
				break;
			case 39:
				cambiarVelocidad(aceleracion);
				break;
			case 38:
				personaje.saltar(velocidad,alto);
				break;
			case 40:
				personaje.bajar();
				break;
			case 13:
				pausar();
				break;
			case 27: 
				inicio = false;
				pausa = true;
				fotogramas = 0;
				fechaUltimoFotograma = new Date().getTime();
				fechaInicio = fechaUltimoFotograma;
				personaje = new RaggedWinionCharacter("personaje", ancho);
				break;
			default:;
		}
	};
	
	
	/**
	 * Función que actualiza el zoom del videojuego en función del tamaño de pantalla.
	 * Function which resize videogame's zoom depending on pantalla size.
	 */
	function redimensionar(e){
		zoom = pantalla.offsetWidth / ancho;
		
		animaciones.width = pantalla.offsetWidth;
		capaPersonaje.width = pantalla.offsetWidth;
		capaElementos.width = pantalla.offsetWidth;
		fondo.width = pantalla.offsetWidth;

		animaciones.height = pantalla.offsetHeight;
		capaPersonaje.height = pantalla.offsetHeight;
		capaElementos.height = pantalla.offsetHeight;
		fondo.height = pantalla.offsetHeight;
	};
	

	
	function nuevoFotograma(){
		var fechaFotograma = new Date().getTime();
		var tiempoEntreFotogramas = Math.ceil(fechaFotograma - fechaUltimoFotograma);
		var tiempoDesdeInicio = Math.ceil(fechaFotograma - fechaInicio);
		if(tiempoEntreFotogramas >= 1000 /fps){
			fotogramas++;
		}
		
		/**
		 * Limpiamos los contextos
		 */
		contextoElementos.clearRect(0, 0, ancho, alto);
		
		cambiarColor();
		
		eventos(tiempoDesdeInicio, tiempoEntreFotogramas);
		
		dibujar();
	};
	
	/**
	 * Función que realiza los eventos pertinentes del fotograma actual.
	 */
	function eventos(tiempoDesdeInicio){
		
		/***Animaciones de inicio***/
		if(tiempoDesdeInicio < 5000){
			velocidad = 10;
			animaciones.style.backgroundColor = "rgb(10,20,20)";
			texto("Espera "+parseInt((5000 - tiempoDesdeInicio) / 1000)+" segundos...");
		}
		
		else if(tiempoDesdeInicio >= 5000 && tiempoDesdeInicio < 5050){
			personaje.aparecer();
		}
		
		else{
			animaciones.style.backgroundColor = "transparent";
			
			personaje.tocarSuelo(verificarApoyo(), alto);
			
			if(verificarColisionMortal()){
				personaje.eliminar();
			}
		}
		


		nivel("Nivel "+parseInt((tiempoDesdeInicio / 60000)+1));
		if(tiempoDesdeInicio >= 60000){
			nivel2(tiempoDesdeInicio);
		}
		else if(tiempoDesdeInicio >= 10000 && tiempoDesdeInicio < 60000){
			nivel1(tiempoDesdeInicio);
		}
		else{
			nivel0(tiempoDesdeInicio);
		}
	};
	
	
	/**
	 * Función que dibuja el fotograma actual.
	 */
	function dibujar(){
		personaje.dibujar(contextoPersonaje, zoom, fps, fotogramas, velocidad);
		
		for(var i = 0; i < elementos.length; i++){
			elementos[i].avanzar(parseInt(velocidad));
			
			if(elementos[i].estaFuera(ancho)){
				elementos.splice(i,1);
			}
			
			else{
				elementos[i].dibujar(contextoElementos, ancho, zoom, fps, fotogramas);
			}
			
		}
	};
	
	
	/**
	 * Función que muestra un texto en el contexto de animaciones
	 * Function that shows a text in animation context
	 */
	function texto(contenido){
		contextoAnimaciones.font = (40*zoom)+"px Sans Sherif";
		contextoAnimaciones.fillStyle = "orange";
		contextoAnimaciones.textAlign = "center";
		contextoAnimaciones.fillText(contenido, ancho*zoom/2, alto*zoom/2);
	};
	
	
	/**
	 * Función que muestra un texto en el contexto de animaciones
	 * Function that shows a text in animation context
	 */
	function nivel(contenido){
		contextoAnimaciones.font = (40*zoom)+"px Sans Sherif";
		contextoAnimaciones.fillStyle = "white";
		contextoAnimaciones.textAlign = "right";
		contextoAnimaciones.fillText(contenido, (ancho-40)*zoom, 40*zoom);
	};
	
	
	/**
	 * Función que altera el color gradualmente.
	 * Function that change color gradually.
	 */
	function cambiarColor(){
		blue = 255 - parseInt(fotogramas / velocidadCambioColor / fps);
		
		
		if(blue < 0){
			blue = 0;
		}
		
		if(blue <= 100){
			green = 100 - parseInt((fotogramas - 155 * velocidadCambioColor * fps) / velocidadCambioColor / fps);
		}
		
		if(green < 0){
			green = 0;
		}
		
		if(green == 0){
			red = 100 - parseInt((fotogramas - 255 * velocidadCambioColor * fps) / velocidadCambioColor / fps);
		}
		
		if(red < 0){
			red = 0;
		}
		
		bgColor = "rgba("+ red +","+ green +","+ blue +", 1)";
		
		fondo.style.backgroundColor = bgColor;
	};
	
	
	/**
	 * Función que comprueba si el personaje está apoyado.
	 */
	function verificarApoyo(){
		for(var i = 0; i < elementos.length; i++){
			
			if(
				elementos[i].getSolido() 
				&& elementos[i].getPosicion().superior == personaje.getPosicion().pies
				&& 
				(
					valorEstaEntreValores(
						personaje.getPosicion().cara
						, elementos[i].getPosicion(ancho).izquierda
						, elementos[i].getPosicion(ancho).derecha
					)
					||
					valorEstaEntreValores(
						personaje.getPosicion().espalda
						, elementos[i].getPosicion(ancho).izquierda
						, elementos[i].getPosicion(ancho).derecha
					)
				)
			){
				return true;
			}
			
		}
		return false;
	};
	
	
	/**
	 * Función que comprueba si el personaje ha chocado contra algun elemento y muere.
	 */
	function verificarColisionMortal(){
		for(var i = 0; i < elementos.length; i++){
			if(
				elementos[i].getMortal() 
				&& (
					valorEstaEntreValores(
						personaje.getPosicion().cabeza
						, elementos[i].getPosicion(ancho).superior
						, elementos[i].getPosicion(ancho).inferior
					)
					||
					valorEstaEntreValores(
						personaje.getPosicion().pies
						, elementos[i].getPosicion(ancho).superior
						, elementos[i].getPosicion(ancho).inferior
					)
				)
				&& 
				(
					valorEstaEntreValores(
						personaje.getPosicion().cara
						, elementos[i].getPosicion(ancho).izquierda
						, elementos[i].getPosicion(ancho).derecha
					)
					||
					valorEstaEntreValores(
						personaje.getPosicion().espalda
						, elementos[i].getPosicion(ancho).izquierda
						, elementos[i].getPosicion(ancho).derecha
					)
				)
			){
				return true;
			}
		}
		
		return false;
	};
	
	
	
	
	
	/******NIVELES DE JUEGO******/
	
	/**
	 * 
	 */
	function nivel0(tiempoDesdeInicio){
		/**Elementos Fondo**/
		var frecuenciaTierra = 400;
		if(tiempoDesdeInicio % frecuenciaTierra < 1000/fps){
			elementos.push(new RaggedWinionTierra(fotogramas, alto, ancho));
		}
		

		/**Elementos **/
		var frecuenciaNube = 800;
		if(tiempoDesdeInicio % frecuenciaNube < 1000/fps){
			elementos.push(new RaggedWinionNube(fotogramas, alto, ancho));
		}
	};
	
	/**
	 * 
	 */
	function nivel1(tiempoDesdeInicio){
		/**Elementos Fondo**/
		var frecuenciaTierra = 400;
		if(tiempoDesdeInicio % frecuenciaTierra < 1000/fps){
			elementos.push(new RaggedWinionTierra(fotogramas, alto, ancho));
		}
		

		/**Elementos **/
		var frecuenciaNube = 100;
		if(tiempoDesdeInicio % frecuenciaNube < 1000/fps){
			elementos.push(new RaggedWinionNube(fotogramas, alto, ancho));
		}
		
		var frecuenciaSoldado = 500;
		if(
			tiempoDesdeInicio % frecuenciaSoldado < 1000/fps
			&& Math.random() * 5 >= 4
		){
			elementos.push(new RaggedWinionSoldado(fotogramas, alto, ancho));
		}
	};

	
	/**
	 * 
	 */
	function nivel2(tiempoDesdeInicio){
		/**Elementos **/
		var frecuenciaNube = 80;
		if(tiempoDesdeInicio % frecuenciaNube < 1000/fps){
			elementos.push(new RaggedWinionNube(fotogramas, alto, ancho));
		}
	};
	
	
	
	
	
	/******FUNCIONES DERIVADAS DE LA INTERACTIVIDAD********/
	
	
	/**
	 * Función que cambia la velocidad del juego.
	 * Function that changes game speed.
	 * 
	 * @param incremento - Cambio producido en la velocidad.
	 */
	function cambiarVelocidad(incremento){
		velocidad += incremento;
		
		if(velocidad > velocidadMax){
			velocidad = velocidadMax;
		}
		
		else if(velocidad < velocidadMin){
			velocidad = velocidadMin;
		}
		console.log("velocidad: "+velocidad);
	};
	
	
	/**
	 * Función que pausa el juego.
	 * Function that pauses the game.
	 */
	function pausar(){
		if(!inicio){
			inicio = true;
			fotograma = 0;
			fechaUltimoFotograma = new Date().getTime();
			fechaInicio = fechaUltimoFotograma;
		}
		
		if(pausa){
			pausa = false;
		}
		
		else{
			pausa = true;
		}
	};
};