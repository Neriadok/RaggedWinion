/**
 * 
 */
function RaggedWinionSoldado(
	fotogramaAparicion
	,altoPantalla
	,anchoPantalla
){
	/******* CONSTRUCTOR *******/	
	/**Objeto Padre - Parent Object**/
	
	var soldado = new RaggedWinionElement(
		100
		, "soldado"
		, fotogramaAparicion
		, altoPantalla-220
		, 200
		, 150
		, true
		, true
		, false
		, null
		, null
	);
	
	/**Atributos - Atributes**/
	
	var recorrido = 0;
	var destruido = false;
	var fotogramaDestruccion = null;
	
	/**Funciones de Inicio - Onload functions**/
	
	/**Asignacion de Eventos - Events' Asignations**/
	
	/**Registro - Logs**/
	
	
	/******* FIN DEL CONSTRUCTOR *******/
	
	
	
	
	/**
	 * Método que dibuja el elemento.
	 * Method which draws the element.
	 * 
	 * @param contexto Canvas Context
	 */
	this.dibujar = function(contexto, anchoPantalla, zoom, fps, fotogramaActual){
		soldado.dibujar(contexto, anchoPantalla, zoom, fps, fotogramaActual);
	};
	
	
	/**
	 * Método que mueve el elemento.
	 */
	this.avanzar = function(avanzado){
		soldado.avanzar(avanzado+3);
	};
	
	
	/**
	 * 
	 */
	this.getPosicion = function(anchoPantalla){
		return soldado.getPosicion(anchoPantalla);
	};

	
	/**
	 * Función que devuelve true si el elemento es solido.
	 */
	this.getSolido = function(){
		return soldado.getSolido();
	};

	
	/**
	 * Función que devuelve true si el elemento es mortal.
	 */
	this.getMortal = function(){
		return soldado.getMortal();
	};
	
	
	/**
	 * Método que mueve el elemento.
	 */
	this.estaFuera = function(anchoPantalla){
		return soldado.estaFuera(anchoPantalla);
	};
};