/**
 * 
 */
function RaggedWinionTierra(
	fotogramaAparicion
	,altoPantalla
	,anchoPantalla
){
	/******* CONSTRUCTOR *******/	
	/**Objeto Padre - Parent Object**/
	
	var tierra = new RaggedWinionElement(
		0
		, "tierra"
		, fotogramaAparicion
		, altoPantalla-50
		, 120
		, anchoPantalla
		, true
		, false
		, false
		, null
		, null
	);
	
	/**Atributos - Atributes**/
	
	var recorrido = 0;
	var destruido = false;
	var fotogramaDestruccion = null;
	
	/**Funciones de Inicio - Onload functions**/
	
	/**Asignacion de Eventos - Events' Asignations**/
	
	/**Registro - Logs**/
	
	
	/******* FIN DEL CONSTRUCTOR *******/
	
	
	
	
	/**
	 * Método que dibuja el elemento.
	 * Method which draws the element.
	 * 
	 * @param contexto Canvas Context
	 */
	this.dibujar = function(contexto, anchoPantalla, zoom, fps, fotogramaActual){
		tierra.dibujar(contexto, anchoPantalla, zoom, fps, fotogramaActual);
	};
	
	
	/**
	 * Método que mueve el elemento.
	 */
	this.avanzar = function(avanzado){
		tierra.avanzar(avanzado);
	};
	
	
	/**
	 * 
	 */
	this.getPosicion = function(anchoPantalla){
		return tierra.getPosicion(anchoPantalla);
	};

	
	/**
	 * Función que devuelve true si el elemento es solido.
	 */
	this.getSolido = function(){
		return tierra.getSolido();
	};

	
	/**
	 * Función que devuelve true si el elemento es mortal.
	 */
	this.getMortal = function(){
		return tierra.getMortal();
	};
	
	
	/**
	 * Método que mueve el elemento.
	 */
	this.estaFuera = function(anchoPantalla){
		return tierra.estaFuera(anchoPantalla);
	};
};