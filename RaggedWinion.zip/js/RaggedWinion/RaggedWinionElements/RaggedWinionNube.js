/**
 * 
 */
function RaggedWinionNube(
	fotogramaAparicion
	,altoPantalla
){
	/******* CONSTRUCTOR *******/	
	/**Objeto Padre - Parent Object**/
	
	var nube = new RaggedWinionElement(
		0
		, "nube"
		, fotogramaAparicion
		, parseInt(parseInt(Math.random() * 4) * altoPantalla / 5 + 100) 
		, 120
		, 200
		, true
		, false
		, false
		, null
		, null
	);
	
	/**Atributos - Atributes**/
	
	var recorrido = 0;
	var destruido = false;
	var fotogramaDestruccion = null;
	
	/**Funciones de Inicio - Onload functions**/
	
	/**Asignacion de Eventos - Events' Asignations**/
	
	/**Registro - Logs**/
	
	
	/******* FIN DEL CONSTRUCTOR *******/
	
	
	
	
	/**
	 * Método que dibuja el elemento.
	 * Method which draws the element.
	 * 
	 * @param contexto Canvas Context
	 */
	this.dibujar = function(contexto, anchoPantalla, zoom, fps, fotogramaActual){
		nube.dibujar(contexto, anchoPantalla, zoom, fps, fotogramaActual);
	};
	
	
	/**
	 * Método que mueve el elemento.
	 */
	this.avanzar = function(avanzado){
		nube.avanzar(avanzado);
	};
	
	
	/**
	 * 
	 */
	this.getPosicion = function(anchoPantalla){
		return nube.getPosicion(anchoPantalla);
	};

	
	/**
	 * Función que devuelve true si el elemento es solido.
	 */
	this.getSolido = function(){
		return nube.getSolido();
	};

	
	/**
	 * Función que devuelve true si el elemento es mortal.
	 */
	this.getMortal = function(){
		return nube.getMortal();
	};
	
	
	/**
	 * Método que verifica si el elemento esta fuera de la pantalla
	 */
	this.estaFuera = function(anchoPantalla){
		return nube.estaFuera(anchoPantalla);
	};
};